package testcases;

import org.openqa.selenium.firefox.FirefoxDriver;
import static org.junit.Assert.*;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import pageobject.*;


public class FunctionalTest {
	
	public WebDriver Driver;
	
	@Before
	public void GetBrowserDriver() {
		WebDriver Driver = new FirefoxDriver();
		this.Driver = Driver;
	}
	
	@Test
	public void OmgeoTest () {
      
	OmgeoHomePage OmgeoPage = new OmgeoHomePage(Driver);
	AboutPage AboutPage = new AboutPage(Driver);
	AlertPage AlertPage = new AlertPage(Driver);
	LeadershipTeamPage LeadershipTeamPage = new LeadershipTeamPage(Driver);
	
	//Open Omgeo home page and verify home page is displayed
	OmgeoPage.NavigateToPageByUrl();
	assertTrue("Omgeo home page is not displayed", OmgeoPage.IsAtPage());
	
	//Click on About link and verify About page is displayed
	OmgeoPage.ClickAbout();
	//Driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	assertTrue("About page is not displayed", AboutPage.IsAtPage());
	
	//Select ALERT product from product dropdown 
	AboutPage.SelectAlertProduct();
	assertTrue("Alert page is not displayed", AlertPage.IsAtPage());
	
	//Navigate to Leadership Team page and verify Leadership Team page is displayed
	AlertPage.NavigateToLeadershipPage();
	assertTrue("Leadership Team page is not displayed", LeadershipTeamPage.IsAtPage());
	
	//Verify Member info is displayed correctly
	assertTrue("Leadship member verification failed", LeadershipTeamPage.VerifyMemberInfo());
	
	}
	
	@After
	public void close () {
		Driver.close();
	}
	
}
