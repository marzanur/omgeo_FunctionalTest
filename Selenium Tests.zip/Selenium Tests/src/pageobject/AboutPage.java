package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class AboutPage {
	
	public WebDriver driver;
	
	public AboutPage(WebDriver driver) {
		this.driver = driver;
	}

	public static String PageTitle = "Post-Trading Solutions for the Global Investment Industry | Omgeo";
	public static String Alert_xpath = "//li[contains(text(),'ALERT')]";
	public static String FindAProduct_dropdown_ID = "selectContainerProduct";
	

	
	public boolean IsAtPage()
	{
		return driver.getTitle().trim().equalsIgnoreCase(PageTitle.trim());
	}
	
	public void SelectAlertProduct()
	{
		driver.findElement(By.id(FindAProduct_dropdown_ID)).click();
		driver.findElement(By.xpath(Alert_xpath)).click();
	}
	


}
