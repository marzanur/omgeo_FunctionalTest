package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OmgeoHomePage {
	
	public static String PageURL = "http://www.omgeo.com";
	public static String PageTitle = "Post-Trade Processing Solutions | Omgeo";
	public static String AboutLink_text = "About";
	
	public WebDriver driver;
	
	public OmgeoHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void NavigateToPageByUrl()
	{
		driver.navigate().to(PageURL);		
	}
	
	public boolean IsAtPage()
	{
		return  driver.getTitle().trim().equalsIgnoreCase(PageTitle.trim());
	}
	
	public void ClickAbout()
	{
		driver.findElement(By.linkText(AboutLink_text)).click();
	}

}
