package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LeadershipTeamPage {
	
	public static String Header_content = "Committed to propelling the industry forward";
	public static String Header_class = "HeroHeaderOrange";
	public static String PaulaArthus_xpath = "//strong[contains(text(), 'Paula Arthus')]/following-sibling::span/a";
	public static String paulaArthus_content = "Paula Arthus is President and CEO of Omgeo, a DTCC subsidiary, where she leads day-to-day operations and new business and product development for the firm" ;
	public static String Iframe_xpath = "//iframe[@src='/page/paula_arthus']";
	public static String PaulaArthus_info = "//td[@width='50%']";

	public WebDriver driver;
	
	public LeadershipTeamPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public boolean IsAtPage()
	{
		return driver.findElement(By.className(Header_class)).getText().trim().equalsIgnoreCase(Header_content.trim());
	}
	
	public boolean VerifyMemberInfo()
	{
		driver.findElement(By.xpath(PaulaArthus_xpath)).click();
		driver.switchTo().frame(driver.findElement(By.xpath(Iframe_xpath)));

		//Wait until the member information is displayed
		WebDriverWait wait = new WebDriverWait(driver, 10);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PaulaArthus_info)));
	    WebElement element = driver.findElement(By.xpath(PaulaArthus_info));
		
		return element.getText().trim().contains(paulaArthus_content);
		
	}
	
	
}
