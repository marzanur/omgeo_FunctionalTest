package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class AlertPage {
	
	public static String PageTitle = "Online Account & Standing Settlement Instructions (SSI) | Omgeo ALERT";
	public static String AboutLink_text = "About";
	public static String LeadershipTeam_linkText = "Leadership Team";
	
	public WebDriver driver;
	
	public AlertPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public boolean IsAtPage()
	{
		return driver.getTitle().trim().equalsIgnoreCase(PageTitle.trim());
	}
	
	public void NavigateToLeadershipPage()
	{
		Actions builder = new Actions(driver);
		builder.moveToElement(driver.findElement(By.linkText(AboutLink_text))).perform();
		driver.findElement(By.linkText(LeadershipTeam_linkText)).click();
	}

}
